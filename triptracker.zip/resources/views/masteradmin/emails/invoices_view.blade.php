<!DOCTYPE html>
<html>
<head>
    <title>View Your Invoice</title>
</head>
<body>
    <p>Dear Customer,</p>
    <p>You can view your invoice by clicking the link below:</p>
    <p><a href="{{ $invoiceViewUrl }}">View Invoice</a></p>
    <p>Thank you!</p>
</body>
</html>