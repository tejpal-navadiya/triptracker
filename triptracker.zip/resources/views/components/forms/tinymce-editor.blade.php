<div>
    <!-- Breathing in, I calm body and mind. Breathing out, I smile. - Thich Nhat Hanh -->
    <form method="post">
        <textarea id="myeditorinstance">Hello, World!</textarea>
      </form>
</div>