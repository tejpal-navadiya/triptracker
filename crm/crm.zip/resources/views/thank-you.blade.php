
<div class="container">
    <div class="text-center">
        <h1>Thank You for Your Subscription!</h1>
        <p>Your payment has been successfully processed, and your subscription is now active.</p>
        <p>You can now log in to access your account and manage your subscription.</p>

        <!-- Button that redirects to the login page -->
        <a href="{{ route('masteradmin.login') }}" class="btn btn-primary">Go to Login</a>
    </div>
</div>
