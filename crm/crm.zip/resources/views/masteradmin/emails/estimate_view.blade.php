<!DOCTYPE html>
<html>
<head>
    <title>View Your Estimate</title>
</head>
<body>
    <p>Dear Customer,</p>
    <p>You can view your estimate by clicking the link below:</p>
    <p><a href="{{ $estimateViewUrl }}">View Estimate</a></p>
    <p>Thank you!</p>
</body>
</html>